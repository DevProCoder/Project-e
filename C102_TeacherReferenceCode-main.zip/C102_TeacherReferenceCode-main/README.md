# C102_TeacherReferenceCode

Python code to move images files from Downloads folder to a new folder.
